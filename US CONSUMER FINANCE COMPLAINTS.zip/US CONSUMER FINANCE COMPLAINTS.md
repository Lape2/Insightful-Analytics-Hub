# **Unveiling Consumer Financial Experiences: Analyzing CFPB Complaints**

# Introduction

Data Source: The dataset used in this project is sourced from Kaggle, a platform for data science and machine learning competitions. The dataset specifically comes from the Consumer Financial Protection Bureau (CFPB) Complaint Database.

About the Dataset: The CFPB Complaint Database contains complaints submitted by consumers regarding various financial products and services. These complaints cover a wide range of issues, including but not limited to credit cards, mortgages, student loans, and debt collection. Each complaint typically includes details such as the consumer's narrative, the type of financial product or service involved, the company being complained about, and the resolution status.

Project Objective: The objective of this project is to analyze the CFPB complaints data to gain insights into consumer experiences with financial products and services. This analysis will involve several steps, including data cleaning and preprocessing, exploratory data analysis (EDA), and visualization. By analyzing the complaints data, we aim to identify common issues, trends over time, sentiments, and other valuable insights that can help improve the financial marketplace.

Data Description: The dataset consists of several columns, including:

Date Received: The date when the complaint was submitted.

Product: The type of financial product or service associated with the complaint (e.g., credit reporting, debt collection).

Issue: The specific issue or problem reported by the consumer.

Consumer Complaint Narrative: The detailed narrative provided by the consumer describing their experience.

Company: The company against which the complaint is filed.

State: The state where the consumer resides.

Zip Code: The zip code of the consumer.

Tags: Additional information or tags associated with the complaint.

Consumer Consent Provided: Indicates whether the consumer provided consent to publish their complaint narrative.

Company Response to Consumer: The response provided by the company to the consumer's complaint.

Timely Response: Indicates whether the company responded to the complaint within the specified time frame.

# Data Processing
Data Processing: The first step after loading the data is to process the data. In this step, I will be handling missing values, standardizing formats, and removing irrelevant information.


```python
# Importing necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset into a pandas DataFrame

df = pd.read_csv(r"C:\Users\olape\OneDrive\Desktop\Personal Projects\consumer_complaints.csv")

# Display the first few rows of the dataset to verify it's loaded correctly
df.head()
```

    C:\Users\olape\AppData\Local\Temp\ipykernel_8068\2803680057.py:9: DtypeWarning: Columns (5,11) have mixed types. Specify dtype option on import or set low_memory=False.
      df = pd.read_csv(r"C:\Users\olape\OneDrive\Desktop\Personal Projects\consumer_complaints.csv")
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date_received</th>
      <th>product</th>
      <th>sub_product</th>
      <th>issue</th>
      <th>sub_issue</th>
      <th>consumer_complaint_narrative</th>
      <th>company_public_response</th>
      <th>company</th>
      <th>state</th>
      <th>zipcode</th>
      <th>tags</th>
      <th>consumer_consent_provided</th>
      <th>submitted_via</th>
      <th>date_sent_to_company</th>
      <th>company_response_to_consumer</th>
      <th>timely_response</th>
      <th>consumer_disputed?</th>
      <th>complaint_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>08/30/2013</td>
      <td>Mortgage</td>
      <td>Other mortgage</td>
      <td>Loan modification,collection,foreclosure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>U.S. Bancorp</td>
      <td>CA</td>
      <td>95993</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Referral</td>
      <td>09/03/2013</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511074</td>
    </tr>
    <tr>
      <th>1</th>
      <td>08/30/2013</td>
      <td>Mortgage</td>
      <td>Other mortgage</td>
      <td>Loan servicing, payments, escrow account</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Wells Fargo &amp; Company</td>
      <td>CA</td>
      <td>91104</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Referral</td>
      <td>09/03/2013</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511080</td>
    </tr>
    <tr>
      <th>2</th>
      <td>08/30/2013</td>
      <td>Credit reporting</td>
      <td>NaN</td>
      <td>Incorrect information on credit report</td>
      <td>Account status</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Wells Fargo &amp; Company</td>
      <td>NY</td>
      <td>11764</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Postal mail</td>
      <td>09/18/2013</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>No</td>
      <td>510473</td>
    </tr>
    <tr>
      <th>3</th>
      <td>08/30/2013</td>
      <td>Student loan</td>
      <td>Non-federal student loan</td>
      <td>Repaying your loan</td>
      <td>Repaying your loan</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Navient Solutions, Inc.</td>
      <td>MD</td>
      <td>21402</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Email</td>
      <td>08/30/2013</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>510326</td>
    </tr>
    <tr>
      <th>4</th>
      <td>08/30/2013</td>
      <td>Debt collection</td>
      <td>Credit card</td>
      <td>False statements or representation</td>
      <td>Attempted to collect wrong amount</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Resurgent Capital Services L.P.</td>
      <td>GA</td>
      <td>30106</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Web</td>
      <td>08/30/2013</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511067</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Count the number of rows in the DataFrame
num_rows = df.shape[0]

# Print the number of rows
print("Number of Rows:", num_rows)

```

    Number of Rows: 555957
    


```python
# Check for missing values in each column
missing_values = df.isnull().sum()

# Calculate the percentage of missing values in each column
missing_percentage = (missing_values / len(df)) * 100

# Create a DataFrame to display the results
missing_data = pd.DataFrame({'Missing Values': missing_values, 'Percentage': missing_percentage})
missing_data.sort_values(by='Percentage', ascending=False, inplace=True)

# Display columns with missing values
print("Columns with Missing Values:")
print(missing_data[missing_data['Missing Values'] > 0])

```

    Columns with Missing Values:
                                  Missing Values  Percentage
    consumer_complaint_narrative          489151   87.983603
    tags                                  477998   85.977513
    company_public_response               470833   84.688744
    consumer_consent_provided             432499   77.793606
    sub_issue                             343335   61.755675
    sub_product                           158322   28.477382
    state                                   4887    0.879025
    zipcode                                 4505    0.810314
    

consumer_complaint_narrative: This column has the highest percentage of missing values (87.98%). It contains detailed narratives provided by consumers, and missing values likely indicate cases where consumers did not provide additional information beyond the standard complaint form.

tags: This column has missing values for 85.98% of the rows. It likely contains additional information or tags associated with the complaints, but many entries are missing this information.

company_public_response: Approximately 84.69% of entries in this column are missing. This column likely contains responses provided by companies to address consumer complaints publicly.

consumer_consent_provided: About 77.79% of entries in this column are missing. It indicates whether consumers provided consent to publish their complaint narrative.

sub_issue: This column has missing values for 61.76% of the rows. It likely contains sub-categories or more specific descriptions of the issues reported by consumers.

sub_product: Around 28.48% of entries in this column are missing. It represents sub-categories of financial products or services associated with the complaints.

state: Only 0.88% of entries in this column are missing, which is relatively small compared to other columns. It represents the state where the consumer resides.

zipcode: Approximately 0.81% of entries in this column are missing. It represents the zip code of the consumer.

Sub_product, state, and zipcode are important coloumns in the dataset and has less than 30% of missing values, hence I will be dropping the rows with the missing values in these coloumns.

Given that the 'sub_product,' 'state,' and 'zipcode' columns are vital for our analysis and have missing values in less than 30% of the dataset, it's reasonable to drop the rows with the missing values. Retaining only data with complete information in these columns ensures the integrity and accuracy of our analysis, focusing on the most relevant and informative data points.


```python
# Drop rows with missing values under specific columns
df.dropna(subset=['sub_product', 'state', 'zipcode'], inplace=True)

# Verify that rows with missing values under those columns have been dropped
print("Number of Rows after dropping missing values:", df.shape[0])

```

    Number of Rows after dropping missing values: 393942
    


```python
# Check for missing values in each column
missing_values = df.isnull().sum()

# Display columns with missing values
print("Columns with Missing Values:")
print(missing_values[missing_values > 0])

```

    Columns with Missing Values:
    sub_issue                       274032
    consumer_complaint_narrative    347729
    company_public_response         340848
    tags                            338194
    consumer_consent_provided       312445
    dtype: int64
    


```python
# Drop irrelevant columns (columns not needed for analysis)
irrelevant_columns = ['sub_issue', 'consumer_complaint_narrative', 'company_public_response', 'tags', 'consumer_consent_provided']
df.drop(columns=irrelevant_columns, inplace=True)

```


```python
# Standardize date formats
df['date_received'] = pd.to_datetime(df['date_received'])
df['date_sent_to_company'] = pd.to_datetime(df['date_sent_to_company'])

# check processed data set
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date_received</th>
      <th>product</th>
      <th>sub_product</th>
      <th>issue</th>
      <th>company</th>
      <th>state</th>
      <th>zipcode</th>
      <th>submitted_via</th>
      <th>date_sent_to_company</th>
      <th>company_response_to_consumer</th>
      <th>timely_response</th>
      <th>consumer_disputed?</th>
      <th>complaint_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-08-30</td>
      <td>Mortgage</td>
      <td>Other mortgage</td>
      <td>Loan modification,collection,foreclosure</td>
      <td>U.S. Bancorp</td>
      <td>CA</td>
      <td>95993</td>
      <td>Referral</td>
      <td>2013-09-03</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511074</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2013-08-30</td>
      <td>Mortgage</td>
      <td>Other mortgage</td>
      <td>Loan servicing, payments, escrow account</td>
      <td>Wells Fargo &amp; Company</td>
      <td>CA</td>
      <td>91104</td>
      <td>Referral</td>
      <td>2013-09-03</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511080</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2013-08-30</td>
      <td>Student loan</td>
      <td>Non-federal student loan</td>
      <td>Repaying your loan</td>
      <td>Navient Solutions, Inc.</td>
      <td>MD</td>
      <td>21402</td>
      <td>Email</td>
      <td>2013-08-30</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>510326</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2013-08-30</td>
      <td>Debt collection</td>
      <td>Credit card</td>
      <td>False statements or representation</td>
      <td>Resurgent Capital Services L.P.</td>
      <td>GA</td>
      <td>30106</td>
      <td>Web</td>
      <td>2013-08-30</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>511067</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2013-08-30</td>
      <td>Bank account or service</td>
      <td>Checking account</td>
      <td>Deposits and withdrawals</td>
      <td>Bank of America</td>
      <td>IL</td>
      <td>60660</td>
      <td>Referral</td>
      <td>2013-09-04</td>
      <td>Closed with explanation</td>
      <td>Yes</td>
      <td>No</td>
      <td>511116</td>
    </tr>
  </tbody>
</table>
</div>



## Analysis and Visualization: Unveiling Consumer Financial Experiences

In this section, I delve into the Consumer Financial Protection Bureau (CFPB) complaints dataset to gain insights into consumer experiences with financial products and services. Through a combination of data analysis and visualization techniques, I aim to uncover trends, identify common issues, and analyze sentiment in consumer narratives.

Exploring Complaint Volume Over Time:
I will begin by examining the volume of complaints received over time. Through a time series analysis, we visualize the trend in complaint volume to understand the overall activity level and identify any significant changes or patterns over the years.

Identifying Common Issues:
Next, I will investigate the most frequent issues reported by consumers. By creating a bar chart showcasing the top 10 most common issues, shed light on recurring problems within the financial marketplace, helping stakeholders prioritize areas for improvement.

Analyzing Sentiment for the topmost issue:
In addition to quantifying complaint volume and identifying common issues, I will analyze the sentiment expressed in the topmost issue. Applying sentiment analysis techniques to the issue allows us to gauge the overall sentiment polarity (positive, negative, or neutral) and gain deeper insights into consumer experiences and perceptions.

Visualization Tools:
Throughout our analysis, I will leverage visualization tools such as Matplotlib and Seaborn to create visually compelling plots and charts that effectively communicate our findings.




```python
# Plotting complaint volume over time with a line graph and markers
plt.figure(figsize=(10, 6))
df['date_received'].dt.year.value_counts().sort_index().plot(kind='line', marker='o', color='red')
plt.title('Complaint Volume Over Time')
plt.xlabel('Year')
plt.ylabel('Number of Complaints')
plt.grid(True)  # grid for better readability
plt.show()

```


    
![png](output_14_0.png)
    


Trend Analysis of Consumer Complaints (2011-2016)

From 2011 to 2016, the volume of consumer complaints showed an interesting pattern, as observed from the data:

In 2011, the number of complaints started at a relatively low level, estimated to be around 0.

By the following year, 2012, there was a notable increase in complaints, rising sharply to over 5,500.

This upward trend continued into 2013, with complaints escalating further to approximately 8,000.

The trend persisted in 2014, as complaints surged to around 11,000.

However, in 2015, there was a slight increase, with complaints reaching approximately 11,500.

Notably, in 2016, there was a significant decrease in the number of complaints, dropping to about 3,000.

Insight:
The visualization illustrates a consistent upward trajectory in consumer complaints from 2011 to 2015, indicating growing dissatisfaction or issues within the financial marketplace. However, the sharp decline in complaints observed in 2016 suggests a notable shift. It's plausible that financial institutions intensified efforts to address consumer grievances, resulting in the substantial reduction in complaints during this period.


```python
# Plotting the most frequent issues
plt.figure(figsize=(10, 6))
top_issues = df['issue'].value_counts().nlargest(10)
top_issues.plot(kind='bar')
plt.title('Top 10 Most Frequent Issues')
plt.xlabel('Issue')
plt.ylabel('Number of Complaints')
plt.xticks(rotation=45, ha='right')
plt.show()

```


    
![png](output_16_0.png)
    


"Loan modification, collection, and foreclosures" is the topmost issue, I can focus on analyzing sentiment specifically for complaints related to this issue. 


```python
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Initialize the sentiment analyzer
nltk.download('vader_lexicon')  # Download the Vader lexicon for sentiment analysis
sia = SentimentIntensityAnalyzer()

# Filter DataFrame for complaints related to "Loan modification, collection, and foreclosures"
loan_complaints = df[df['issue'] == 'Loan modification,collection,foreclosure']

# Function to calculate sentiment polarity
def calculate_sentiment(text):
    sentiment_score = sia.polarity_scores(str(text))
    return sentiment_score['compound']

# Apply sentiment analysis to the filtered complaints
loan_complaints['sentiment'] = loan_complaints['company_response_to_consumer'].apply(calculate_sentiment)

# Plotting sentiment distribution
plt.figure(figsize=(8, 6))
sns.histplot(loan_complaints['sentiment'], bins=20, kde=True)
plt.title('Sentiment Distribution in "Loan Modification, Collection, and Foreclosure" Complaints')
plt.xlabel('Sentiment Polarity')
plt.ylabel('Frequency')
plt.show()

```

    [nltk_data] Downloading package vader_lexicon to
    [nltk_data]     C:\Users\olape\AppData\Roaming\nltk_data...
    [nltk_data]   Package vader_lexicon is already up-to-date!
    C:\Users\olape\AppData\Local\Temp\ipykernel_8068\2074582710.py:17: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      loan_complaints['sentiment'] = loan_complaints['company_response_to_consumer'].apply(calculate_sentiment)
    


    
![png](output_18_1.png)
    


The sentiment analysis of complaints related to 'Loan modification, collection, and foreclosures' reveals that the majority of sentiments expressed are neutral, with the highest bar in the sentiment distribution plot centered around 0. This suggests that consumers are generally expressing their concerns or experiences without conveying strong positive or negative emotions. While neutral sentiment predominates, it's important to further analyze the context and content of the complaints to gain a comprehensive understanding of consumer feedback regarding these financial activities.


```python
# Calculate the total number of complaints for each company
company_complaints_total_sorted = company_complaints_total.sort_values(by='total_complaints', ascending=False)

# Display the list of companies with the total number of complaints from highest to lowest
print("List of Companies with Total Number of Complaints (from highest to lowest):")
print(company_complaints_total_sorted)


# Find the company with the most complaints
company_with_most_complaints = company_complaints_total.loc[company_complaints_total['total_complaints'].idxmax()]

# Display thecompany with the most complaints
print("\nCompany with the Most Complaints:")
print(company_with_most_complaints)

```

    List of Companies with Total Number of Complaints (from highest to lowest):
                                        company  total_complaints
    0                           Bank of America             48223
    1                     Wells Fargo & Company             38572
    2                      JPMorgan Chase & Co.             25682
    3                                     Ocwen             20816
    4                       Nationstar Mortgage             13157
    ...                                     ...               ...
    3063                           Spiriter LLC                 1
    3064            AMRON PROFESSIONAL SERVICES                 1
    3065       Hometown Mortgage Services, Inc.                 1
    3066  Homeowner's Mortgage of America, Inc.                 1
    3571             Pohler and Associates, LLC                 1
    
    [3572 rows x 2 columns]
    
    Company with the Most Complaints:
    company             Bank of America
    total_complaints              48223
    Name: 0, dtype: object
    

The list ranks companies based on total complaints, with Bank of America leading at 48,223 complaints, followed by Wells Fargo & Company with 38,572. JPMorgan Chase & Co. ranks third with 25,682 complaints. Notable mentions include Ocwen with 20,816 complaints and Nationstar Mortgage with 13,157.


```python
# Filter the list of companies to include only the top 5 with the most complaints
top_5_companies = company_complaints_total_sorted.head(5)

# Create a bar chart for the distribution of total complaints among the top 5 companies
plt.figure(figsize=(10, 6))
sns.barplot(x='total_complaints', y='company', data=top_5_companies, palette='viridis')
plt.title('Top 5 Companies with the Most Complaints')
plt.xlabel('Number of Complaints')
plt.ylabel('Company')
plt.tight_layout()
plt.show()

```


    
![png](output_22_0.png)
    



```python
# Create a pie chart for the distribution of complaints among the top 5 companies
plt.figure(figsize=(8, 8))
plt.pie(top_5_companies['total_complaints'], labels=top_5_companies['company'], autopct='%1.1f%%', startangle=140, colors=sns.color_palette('viridis', len(top_5_companies)))
plt.title('Distribution of Complaints Among Top 5 Companies')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()

```


    
![png](output_23_0.png)
    



```python
# Filter the dataset to include only complaints related to the top 5 companies
top_5_company_complaints = df[df['company'].isin(top_5_companies['company'])]

# Group the data by company and issue to count the number of complaints for each issue within each company
top_5_company_issue_counts = top_5_company_complaints.groupby(['company', 'issue']).size().reset_index(name='complaints_count')

# Create subplots for each company to visualize the top issues
plt.figure(figsize=(15, 10))

for i, company in enumerate(top_5_companies['company']):
    plt.subplot(2, 3, i+1)
    company_issue_counts = top_5_company_issue_counts[top_5_company_issue_counts['company'] == company]
    top_issues = company_issue_counts.nlargest(5, 'complaints_count')
    plt.barh(top_issues['issue'], top_issues['complaints_count'], color='red')
    plt.title(company)
    plt.xlabel('Number of Complaints')
    plt.ylabel('Issue')

plt.tight_layout()
plt.show()

```


    
![png](output_24_0.png)
    


The consistent appearance of "loan modification, collection, and foreclosures" and "loan servicing, payments, and escrow account" as the top two issues across the top 5 companies suggests several insights:

Industry-Wide Challenges: The recurrence of these issues across multiple companies indicates that they are pervasive challenges within the financial industry, particularly in sectors such as mortgage lending and servicing. These issues may stem from systemic issues in processes, regulations, or customer communication.

Consumer Priorities: The prevalence of these issues suggests that consumers are most concerned about matters related to loan modifications, collections, payments, and escrow accounts. This insight can guide companies in prioritizing their efforts to address these key pain points and improve customer satisfaction.


```python
# Count the frequency of different company responses
company_responses = df['company_response_to_consumer'].value_counts()

# Count the frequency of timely responses
timely_responses = df['timely_response'].value_counts()

# Count the frequency of consumer disputes
consumer_disputes = df['consumer_disputed?'].value_counts()

# Visualize the results
plt.figure(figsize=(15, 5))

# Plot company responses
plt.subplot(1, 3, 1)
company_responses.plot(kind='bar', color='skyblue')
plt.title('Company Response to Consumer')
plt.xlabel('Response Type')
plt.ylabel('Frequency')

# Plot timely responses
plt.subplot(1, 3, 2)
timely_responses.plot(kind='bar', color='lightgreen')
plt.title('Timely Responses')
plt.xlabel('Timely Response')
plt.ylabel('Frequency')

# Plot consumer disputes
plt.subplot(1, 3, 3)
consumer_disputes.plot(kind='bar', color='salmon')
plt.title('Consumer Disputes')
plt.xlabel('Consumer Disputed?')
plt.ylabel('Frequency')

plt.tight_layout()
plt.show()

```


    
![png](output_26_0.png)
    


From the visualization, it appears that the most common company response to consumers is "Closed with explanation," indicating that companies often provide explanations or resolutions to consumer complaints. Additionally, a majority of responses are timely, suggesting that companies strive to address complaints promptly. However, it's notable that a significant portion of consumers do not dispute the resolutions provided by the companies, indicating a level of satisfaction or acceptance with the outcomes.

The prevalence of "Closed with explanation" as the most common company response implies that many complaints may arise from misunderstandings or miscommunication regarding bank services. By providing explanations, financial institutions aim to clarify misunderstandings and address consumer concerns, suggesting a focus on improving communication and transparency to enhance customer satisfaction.


```python
import plotly.express as px

# Create a choropleth map for the distribution of complaints across states
state_complaints = df['state'].value_counts().reset_index()
state_complaints.columns = ['state', 'complaints']

fig = px.choropleth(state_complaints, 
                    locations='state', 
                    locationmode='USA-states', 
                    scope='usa',
                    color='complaints', 
                    hover_name='state', 
                    color_continuous_scale='Blues',
                    title='Distribution of Complaints Across States')
fig.show()

# Create a treemap for the distribution of complaints across products and sub-products
product_complaints = df.groupby(['product', 'sub_product']).size().reset_index(name='complaints')
fig = px.treemap(product_complaints, 
                 path=['product', 'sub_product'], 
                 values='complaints', 
                 title='Distribution of Complaints Across Products and Sub-Products')
fig.show()


```


<div>                            <div id="9eda6844-e3b9-4092-9c5c-e718bb80520f" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("9eda6844-e3b9-4092-9c5c-e718bb80520f")) {                    Plotly.newPlot(                        "9eda6844-e3b9-4092-9c5c-e718bb80520f",                        [{"coloraxis":"coloraxis","geo":"geo","hovertemplate":"<b>%{hovertext}</b><br><br>state=%{location}<br>complaints=%{z}<extra></extra>","hovertext":["CA","FL","TX","NY","GA","NJ","PA","IL","MD","OH","VA","NC","MI","AZ","WA","MA","CO","TN","MO","SC","OR","NV","MN","CT","IN","WI","AL","LA","KY","OK","DC","NH","UT","DE","KS","MS","NM","AR","IA","RI","HI","ME","ID","NE","WV","PR","VT","MT","SD","AK","WY","ND","AE","AP","VI","GU","FM","MH","AS","MP","AA","PW"],"locationmode":"USA-states","locations":["CA","FL","TX","NY","GA","NJ","PA","IL","MD","OH","VA","NC","MI","AZ","WA","MA","CO","TN","MO","SC","OR","NV","MN","CT","IN","WI","AL","LA","KY","OK","DC","NH","UT","DE","KS","MS","NM","AR","IA","RI","HI","ME","ID","NE","WV","PR","VT","MT","SD","AK","WY","ND","AE","AP","VI","GU","FM","MH","AS","MP","AA","PW"],"name":"","z":[60657,39132,26019,25919,18320,16656,14443,13962,13153,12606,12335,11041,11024,9066,8440,8005,6728,6140,5405,4934,4862,4736,4717,4608,4373,4334,3987,3874,2812,2555,2272,2179,2148,2076,1885,1838,1823,1636,1504,1387,1385,1370,1336,1267,953,692,674,602,520,420,368,294,148,105,92,48,22,20,12,11,7,5],"type":"choropleth"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"geo":{"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"center":{},"scope":"usa"},"coloraxis":{"colorbar":{"title":{"text":"complaints"}},"colorscale":[[0.0,"rgb(247,251,255)"],[0.125,"rgb(222,235,247)"],[0.25,"rgb(198,219,239)"],[0.375,"rgb(158,202,225)"],[0.5,"rgb(107,174,214)"],[0.625,"rgb(66,146,198)"],[0.75,"rgb(33,113,181)"],[0.875,"rgb(8,81,156)"],[1.0,"rgb(8,48,107)"]]},"legend":{"tracegroupgap":0},"title":{"text":"Distribution of Complaints Across States"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('9eda6844-e3b9-4092-9c5c-e718bb80520f');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



<div>                            <div id="3dc662fd-8a7f-430d-bf29-e629aebb0b3f" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("3dc662fd-8a7f-430d-bf29-e629aebb0b3f")) {                    Plotly.newPlot(                        "3dc662fd-8a7f-430d-bf29-e629aebb0b3f",                        [{"branchvalues":"total","domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"hovertemplate":"labels=%{label}<br>complaints=%{value}<br>parent=%{parent}<br>id=%{id}<extra></extra>","ids":["Bank account or service/(CD) Certificate of deposit","Debt collection/Auto","Bank account or service/Cashing a check without an account","Other financial service/Check cashing","Bank account or service/Checking account","Mortgage/Conventional adjustable mortgage (ARM)","Mortgage/Conventional fixed mortgage","Debt collection/Credit card","Other financial service/Credit repair","Other financial service/Debt settlement","Money transfers/Domestic (US) money transfer","Prepaid card/Electronic Benefit Transfer / EBT card","Mortgage/FHA mortgage","Debt collection/Federal student loan","Other financial service/Foreign currency exchange","Prepaid card/General purpose card","Prepaid card/Gift or merchant card","Prepaid card/Government benefit payment card","Mortgage/Home equity loan or line of credit","Debt collection/I do not know","Prepaid card/ID prepaid card","Consumer Loan/Installment loan","Money transfers/International money transfer","Debt collection/Medical","Prepaid card/Mobile wallet","Other financial service/Money order","Debt collection/Mortgage","Debt collection/Non-federal student loan","Student loan/Non-federal student loan","Debt collection/Other (i.e. phone, health club, etc.)","Bank account or service/Other bank product/service","Mortgage/Other mortgage","Prepaid card/Other special purpose card","Consumer Loan/Pawn loan","Debt collection/Payday loan","Payday loan/Payday loan","Prepaid card/Payroll card","Consumer Loan/Personal line of credit","Other financial service/Refund anticipation check","Mortgage/Reverse mortgage","Bank account or service/Savings account","Mortgage/Second mortgage","Consumer Loan/Title loan","Prepaid card/Transit card","Other financial service/Traveler\u00e2\u0080\u0099s/Cashier\u00e2\u0080\u0099s checks","Mortgage/VA mortgage","Consumer Loan/Vehicle lease","Consumer Loan/Vehicle loan","Bank account or service","Consumer Loan","Debt collection","Money transfers","Mortgage","Other financial service","Payday loan","Prepaid card","Student loan"],"labels":["(CD) Certificate of deposit","Auto","Cashing a check without an account","Check cashing","Checking account","Conventional adjustable mortgage (ARM)","Conventional fixed mortgage","Credit card","Credit repair","Debt settlement","Domestic (US) money transfer","Electronic Benefit Transfer / EBT card","FHA mortgage","Federal student loan","Foreign currency exchange","General purpose card","Gift or merchant card","Government benefit payment card","Home equity loan or line of credit","I do not know","ID prepaid card","Installment loan","International money transfer","Medical","Mobile wallet","Money order","Mortgage","Non-federal student loan","Non-federal student loan","Other (i.e. phone, health club, etc.)","Other bank product/service","Other mortgage","Other special purpose card","Pawn loan","Payday loan","Payday loan","Payroll card","Personal line of credit","Refund anticipation check","Reverse mortgage","Savings account","Second mortgage","Title loan","Transit card","Traveler\u00e2\u0080\u0099s/Cashier\u00e2\u0080\u0099s checks","VA mortgage","Vehicle lease","Vehicle loan","Bank account or service","Consumer Loan","Debt collection","Money transfers","Mortgage","Other financial service","Payday loan","Prepaid card","Student loan"],"name":"","parents":["Bank account or service","Debt collection","Bank account or service","Other financial service","Bank account or service","Mortgage","Mortgage","Debt collection","Other financial service","Other financial service","Money transfers","Prepaid card","Mortgage","Debt collection","Other financial service","Prepaid card","Prepaid card","Prepaid card","Mortgage","Debt collection","Prepaid card","Consumer Loan","Money transfers","Debt collection","Prepaid card","Other financial service","Debt collection","Debt collection","Student loan","Debt collection","Bank account or service","Mortgage","Prepaid card","Consumer Loan","Debt collection","Payday loan","Prepaid card","Consumer Loan","Other financial service","Mortgage","Bank account or service","Mortgage","Consumer Loan","Prepaid card","Other financial service","Mortgage","Consumer Loan","Consumer Loan","","","","","","","","",""],"values":[2775,2504,454,154,43629,20878,56997,20695,53,139,1750,5,19107,1762,39,1151,224,221,8896,21475,144,5257,1923,13244,235,69,3415,2110,15722,29380,10599,73400,121,59,5757,3846,312,1496,38,1523,3894,658,324,30,50,3726,1630,12072,61351,20838,100342,3673,185185,542,3846,2443,15722],"type":"treemap"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"legend":{"tracegroupgap":0},"title":{"text":"Distribution of Complaints Across Products and Sub-Products"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('3dc662fd-8a7f-430d-bf29-e629aebb0b3f');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


The fact that California has the highest number of complaints suggests that there may be specific challenges or issues within the state's financial services sector that need attention or improvement. Additionally, the observation that mortgage-related complaints are the highest indicates potential issues or dissatisfaction related to mortgage products or services in general. 

**Conclusion:**

In this project, I analyzed consumer complaints about financial products and services using Python. Here's a summary of my work and the key insights:

1. **Data Exploration and Preprocessing:**
   - I obtained the consumer complaints dataset from Kaggle and explored its structure and contents.
   - I identified missing values and handled them appropriately, dropping columns with a high percentage of missing data.
   - The dataset contained information about various aspects of complaints, including product types, issues, company responses, and more.

2. **Analysis and Visualization:**
   - I visualized the distribution of complaints over time, identifying trends and fluctuations in complaint volume.
   - The analysis revealed an increasing trend in complaints over the years, with a notable decrease in 2016, suggesting improvements in addressing consumer concerns by financial institutions.
   - I explored common issues reported by consumers and visualized them using bar charts, highlighting the most frequent issues such as loan modifications, collections, and payments.
   - Sentiment analysis was not feasible due to the absence of consumer complaint narratives, which were largely missing from the dataset.

3. **Named Entity Recognition (NER):**
   - I considered applying NER techniques to extract meaningful entities from consumer complaint narratives. However, due to a high percentage of missing data in the narrative column, this approach was not feasible.

4. **Insights:**
   - California emerged as the state with the highest number of complaints, indicating potential challenges or issues within its financial services sector.
   - Mortgage-related complaints were prevalent, suggesting issues or dissatisfaction with mortgage products or services.
   - Most complaints were closed with an explanation, indicating efforts by financial institutions to address consumer concerns promptly.
   - The majority of responses were timely, indicating a focus on addressing complaints in a timely manner.
   - A significant portion of consumers did not dispute the resolutions provided by companies, suggesting a level of satisfaction or acceptance with the outcomes.

**Overall, the analysis provides valuable insights into consumer complaints about financial products and services, highlighting areas for improvement and opportunities for enhancing customer satisfaction and regulatory compliance in the financial marketplace.**



```python

```


```python

```
